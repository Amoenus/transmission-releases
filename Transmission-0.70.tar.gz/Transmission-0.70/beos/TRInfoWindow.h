// $Id: TRInfoWindow.h 1505 2007-02-22 12:49:34Z bvarner $

#ifndef TR_INFO_WIND
#define TR_INFO_WIND

#include <Box.h>
#include <Window.h>
#include <StringView.h>

#include "transmission.h"

class TRInfoWindow : public BWindow {
public:
	TRInfoWindow(tr_stat_t *status, tr_info_t *info, char *folder);
	~TRInfoWindow();
	
	virtual void FrameResized(float width, float height);
private:
	void StringForFileSize(uint64_t size, BString *str);
	
	BBox *fBox;
};

#endif
