#! /bin/sh

# Hem
VERSION=`grep ^VERSION_STRING Jamrules | sed 's/VERSION_STRING = \([^ ]*\) ;/\1/'`

rm -rf tmp
mkdir tmp
cp -r Transmission.app tmp/
cp AUTHORS tmp/AUTHORS.txt
cp LICENSE tmp/LICENSE.txt
cp NEWS tmp/NEWS.txt
( echo "[InternetShortcut]"; \
  echo "URL=http://transmission.m0k.org/" ) > "tmp/Homepage.url"
( echo "[InternetShortcut]"; \
  echo "URL=http://transmission.m0k.org/forum/" ) > "tmp/Forums.url"
( echo "[InternetShortcut]"; \
  echo "URL=http://transmission.m0k.org/contribute.php" ) > "tmp/Contribute.url"

rm -rf "Transmission $VERSION"
mv tmp "Transmission $VERSION"
