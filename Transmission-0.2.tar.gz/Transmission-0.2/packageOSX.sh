#! /bin/sh

# Hem
TR_VERSION=`grep ^TR_VERSION configure | sed 's/TR_VERSION="\([^"]*\)"/\1/'`

rm -rf tmp
mkdir tmp
cp -r Transmission.app transmissioncli tmp/
cp AUTHORS tmp/AUTHORS.txt
cp LICENSE tmp/LICENSE.txt
cp NEWS tmp/NEWS.txt
echo "[InternetShortcut]\nURL=http://transmission.m0k.org/" > \
    "tmp/Homepage.url"
echo "[InternetShortcut]\nURL=http://transmission.m0k.org/forum/" > \
    "tmp/Forums.url"
echo "[InternetShortcut]\nURL=http://transmission.m0k.org/contribute.php" > \
    "tmp/Contribute.url"

rm -rf "Transmission $TR_VERSION"
mv tmp "Transmission $TR_VERSION"
