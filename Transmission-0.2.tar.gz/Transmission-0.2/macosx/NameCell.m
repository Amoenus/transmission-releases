/******************************************************************************
 * Copyright (c) 2005 Eric Petit
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *****************************************************************************/

#include "NameCell.h"

static NSString * stringForFileSize( uint64_t size )
{
    if( size < 1024 )
    {
        return [NSString stringWithFormat: @" (%lld bytes)", size];
    }
    if( size < 1048576 )
    {
        return [NSString stringWithFormat: @" (%lld.%lld KB)",
                size / 1024, ( size % 1024 ) / 103];
    }
    if( size < 1073741824 )
    {
        return [NSString stringWithFormat: @" (%lld.%lld MB)",
                size / 1048576, ( size % 1048576 ) / 104858];
    }
    return [NSString stringWithFormat: @" (%lld.%lld GB)",
            size / 1073741824, ( size % 1073741824 ) / 107374183];
}

static float widthForString( NSString * string, float fontSize )
{
    NSMutableDictionary * attributes =
        [NSMutableDictionary dictionaryWithCapacity: 1];
    [attributes setObject: [NSFont messageFontOfSize: fontSize]
        forKey: NSFontAttributeName];

    return [string sizeWithAttributes: attributes].width;
}

static NSString * stringFittingInWidth( char * string, float width,
                                        float fontSize )
{
    NSString * nsString = NULL;
    char     * foo      = strdup( string );
    int        i;

    for( i = strlen( string ); i > 0; i-- )
    {
        foo[i] = '\0';
        nsString = [NSString stringWithFormat: @"%s%@",
            foo, ( i - strlen( string ) ? [NSString
            stringWithUTF8String:"\xE2\x80\xA6"] : @"" )];

        if( widthForString( nsString, fontSize ) <= width )
        {
            break;
        }
    }
    free( foo );
    return nsString;
}

@implementation NameCell

- (void) setStat: (tr_stat_t *) stat;
{
    fStat = *stat;
}

- (void) drawWithFrame: (NSRect) cellFrame inView: (NSView *) view
{
    if( ![view lockFocusIfCanDraw] )
    {
        return;
    }

    NSString * nameString = NULL, * timeString, * peersString;
    NSMutableDictionary * attributes;
    attributes = [NSMutableDictionary dictionaryWithCapacity: 1];
    NSPoint pen = cellFrame.origin;
    
    NSString * sizeString = stringForFileSize( fStat.info->totalSize );

    nameString = [NSString stringWithFormat: @"%@%@",
        stringFittingInWidth( fStat.info->name, cellFrame.size.width -
                10 - widthForString( sizeString, 12 ), 12 ),
        sizeString];

    if( fStat.status & TR_STATUS_PAUSE )
    {
        timeString = [NSString stringWithFormat:
            @"Paused (%.2f %%)", 100 * fStat.progress];
        peersString = @"";
    }
    else if( fStat.status & TR_STATUS_CHECK )
    {
        timeString = [NSString stringWithFormat:
            @"Checking existing files (%.2f %%)", 100 * fStat.progress];
        peersString = @"";
    }
    else if( fStat.status & TR_STATUS_DOWNLOAD )
    {
        if( fStat.eta < 0 )
        {
            timeString = [NSString stringWithFormat:
                @"Finishing in --:--:-- (%.2f %%)", 100 * fStat.progress];
        }
        else
        {
            timeString = [NSString stringWithFormat:
                @"Finishing in %02d:%02d:%02d (%.2f %%)",
                fStat.eta / 3600, ( fStat.eta / 60 ) % 60,
                fStat.eta % 60, 100 * fStat.progress];
        }
        if( fStat.status & TR_TRACKER_ERROR )
        {
            peersString = [NSString stringWithFormat: @"%@%@",
                @"Error: ", stringFittingInWidth( fStat.error,
                    cellFrame.size.width - 15 -
                    widthForString( @"Error: ", 10 ), 10 )];
        }
        else
        {
            peersString = [NSString stringWithFormat:
                @"Downloading from %d of %d peer%s",
                fStat.peersUploading, fStat.peersTotal,
                ( fStat.peersTotal == 1 ) ? "" : "s"];
        }
    }
    else
    {
        timeString  = [NSString stringWithFormat:
            @"Seeding, uploading to %d of %d peer%s",
            fStat.peersDownloading, fStat.peersTotal,
            ( fStat.peersTotal == 1 ) ? "" : "s"];
        peersString = @"";
    }

    [attributes setObject: [NSFont messageFontOfSize:12.0]
        forKey: NSFontAttributeName];

    pen.x += 5; pen.y += 5;
    [nameString drawAtPoint: pen withAttributes: attributes];

    [attributes setObject: [NSFont messageFontOfSize:10.0]
        forKey: NSFontAttributeName];

    pen.x += 5; pen.y += 20;
    [timeString drawAtPoint: pen withAttributes: attributes];

    pen.x += 0; pen.y += 15;
    [peersString drawAtPoint: pen withAttributes: attributes];

    [view unlockFocus];
}

@end
